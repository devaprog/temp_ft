import 'package:flutter/material.dart';

class VotingPage extends StatelessWidget {
  final String electionName;
  final List<String> candidates;

  VotingPage({this.electionName, this.candidates});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Voting")),
      body: ListView.builder(
        itemCount: candidates.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(candidates[index]),
            leading: Radio(
              value: index,
              groupValue: null, // This needs to be managed for selection
              onChanged: (value) {
                // Handle voting logic here
              },
            ),
          );
        },
      ),
    );
  }
}

