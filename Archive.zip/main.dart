import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MaterialApp(home: LoginPage()));
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadQiskitID();
  }

  _loadQiskitID() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String qiskitId = prefs.getString('qiskit_id') ?? '';
    _controller.text = qiskitId;
  }

  _saveQiskitID(String qiskitId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('qiskit_id', qiskitId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: 'Enter your Qiskit ID'),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              _saveQiskitID(_controller.text);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DashboardPage()),
              );
            },
            child: Text('Continue'),
          )
        ],
      ),
    );
  }
}
